public class Card {

    private String suit;

    public Card(String suit) {
        this.suit = suit;
    }

    public String getSuit(){
        return this.suit;
    }

}